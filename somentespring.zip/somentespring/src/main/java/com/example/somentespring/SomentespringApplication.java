package com.example.somentespring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SomentespringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SomentespringApplication.class, args);
	}

}
