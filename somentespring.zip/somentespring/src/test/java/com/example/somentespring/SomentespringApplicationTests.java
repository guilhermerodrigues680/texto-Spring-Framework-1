package com.example.somentespring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SomentespringApplicationTests {

	@Test
	void contextLoads() {
	}

}
